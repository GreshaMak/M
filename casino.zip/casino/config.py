TOKEN = "7226718973:AAFyiLw6cPx7M2k0R2RnmOfWj3sfCnEGozg" #токен BotFather
CRYPTO_TOKEN = "204976:AAA6CAu2ddQUBHUKZkDp3HUCnVjRnzvMvlN" #токен CreptoPay
LOG_CHANNEL = -1002227466326 #ЛОГИРОВАНИЕ
CHANNEL_BROKER = -1002167787323 #Посредник
MAIN_CHANNEL = -1002167787323 #основа
ADMINS = [7016182279] #список админов
CHECK_URL = "http://t.me/send?start=IVZWOcPuaBcI" #юрл счёта
MONEYBACK = 0 #процент манибэка от игры
